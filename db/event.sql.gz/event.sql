-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 01, 2018 at 03:20 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `event`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminstration`
--

CREATE TABLE IF NOT EXISTS `adminstration` (
  `AID` int(11) NOT NULL AUTO_INCREMENT,
  `ANAME` varchar(150) NOT NULL,
  `APASS` varchar(11) NOT NULL,
  PRIMARY KEY (`AID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adminstration`
--

INSERT INTO `adminstration` (`AID`, `ANAME`, `APASS`) VALUES
(1, 'admin', 'priya1');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `BID` int(11) NOT NULL AUTO_INCREMENT,
  `PID` int(11) NOT NULL,
  `Cname` varchar(11) NOT NULL,
  `person` int(11) NOT NULL,
  PRIMARY KEY (`BID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`BID`, `PID`, `Cname`, `person`) VALUES
(14, 8, 'payal', 20),
(13, 6, 'rashmi', 5),
(12, 1, 'priya', 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `CNAME` varchar(150) NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CID`, `CNAME`) VALUES
(5, 'classes and workshop'),
(4, 'parties'),
(3, 'nature and park'),
(6, 'health and wellness');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(150) NOT NULL,
  `COMMENT` text NOT NULL,
  `LOGS` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`ID`, `NAME`, `COMMENT`, `LOGS`) VALUES
(1, 'priya', 'wonderful experience', '2018-11-14 20:07:12'),
(5, 'Rashmi kumari', 'I got lot of new skill and talent', '2018-11-22 12:37:49'),
(6, 'Payal Gupta', 'Best party of my life', '2018-11-20 12:38:59'),
(7, 'likhta', 'Your additional services are awesome...', '2018-12-04 12:39:52');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE IF NOT EXISTS `package` (
  `PID` int(11) NOT NULL AUTO_INCREMENT,
  `Location` varchar(110) NOT NULL,
  `price` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `description` text NOT NULL,
  `CNAME` varchar(100) NOT NULL,
  `TNAME` varchar(150) NOT NULL,
  `IMG` varchar(300) NOT NULL,
  PRIMARY KEY (`PID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`PID`, `Location`, `price`, `date`, `description`, `CNAME`, `TNAME`, `IMG`) VALUES
(1, 'bangalore', '7000', '2018-11-15', 'hgfdsg', 'nature and park', 'parks', 'Bangalore'),
(8, 'Bangalore', '1000', '2018-12-25', 'How it works\r\n\r\nStep 1: Each Person is given a canvas, (or other material to paint on if applicable) brushes, easels, an apron and other materials required.\r\nStep 2: Everyone will be given step by step instructions on how to make the painting while an artist paints with them.\r\nStep 3: Everyone can take home the painting they have created! ', 'classes and workshop', 'Bottle Decor', 'img/bottle2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(20) NOT NULL,
  `USERNAME` varchar(20) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `PASSWORD` int(20) NOT NULL,
  `QUESTION` text NOT NULL,
  `ANSWER` varchar(50) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `IMAGE` varchar(500) NOT NULL,
  `PHONE` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`ID`, `NAME`, `USERNAME`, `EMAIL`, `PASSWORD`, `QUESTION`, `ANSWER`, `ADDRESS`, `IMAGE`, `PHONE`) VALUES
(1, 'priya', 'priya', 'pia.kumari@gmail.com', 1234, 'What is your Fav Pen?', 'freg', 'Behind laxmi medical\r\nMurarka Compound,Chowk\r\nPatna city', 'img/pexels-photo-1542085.jpeg', 2147483647),
(6, 'Payal Gupta', 'pg', 'payal@hotmail.ccom', 1234, 'What is your Fav Bike?', 'zen', '14/5, Hesarghatta Main Rd, Chikkasandra, Jalahalli West', 'img/pexels-photo-952005 (1).jpeg', 986543210),
(5, 'Rashmi kumari', 'rashmi', 'rashmi@yahoo.com', 1234, 'What is your Fav Color?', 'red', '14/5, Hesarghatta Main Rd, Chikkasandra, Jalahalli West', 'img/u1.jpeg', 976345278),
(7, 'Likhita Raghu', 'likrag', 'likhtag@gmail.comm', 123, 'What is your Fav Pen?', 'likho', '14/5, Hesarghatta Main Rd, Chikkasandra, Jalahalli West', 'img/pexels-photo-1542085.jpeg', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
  `SID` int(11) NOT NULL AUTO_INCREMENT,
  `Sname` varchar(100) NOT NULL,
  `Sprice` int(11) NOT NULL,
  PRIMARY KEY (`SID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`SID`, `Sname`, `Sprice`) VALUES
(1, 'food', 0),
(2, 'staff', 0);

-- --------------------------------------------------------

--
-- Table structure for table `theme`
--

CREATE TABLE IF NOT EXISTS `theme` (
  `TID` int(11) NOT NULL AUTO_INCREMENT,
  `TNAME` varchar(150) NOT NULL,
  PRIMARY KEY (`TID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `theme`
--

INSERT INTO `theme` (`TID`, `TNAME`) VALUES
(6, 'cake decoration'),
(7, 'java workshop'),
(8, 'Bottle Decor'),
(9, 'Clay art workshop'),
(10, 'Automation and Robotics Application'),
(11, 'Diwali'),
(12, 'Yoga'),
(13, 'Yoga');
